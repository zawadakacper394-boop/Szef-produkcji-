# Gotowa strona z muzyką

W tym folderze znajdują się:
- index.html — gotowa strona
- utwor.mp3 — Twój utwór
- okladka.jpg — zdjęcie użyte jako okładka

## Jak opublikować

Najprościej użyć hostingu, który pozwala wgrać cały folder jako stronę statyczną.
Po publikacji otrzymasz adres w rodzaju:
https://twoja-strona.example/

Ten adres będzie można zamienić na kod QR.

## Ważne
Przeglądarki telefonów zwykle blokują automatyczne odtwarzanie dźwięku po wejściu na stronę. Dlatego strona ma widoczny przycisk ▶ — po zeskanowaniu QR wystarczy go nacisnąć.

Nie zmieniaj nazw `index.html`, `utwor.mp3` i `okladka.jpg`, chyba że odpowiednio zmienisz je również w kodzie.
